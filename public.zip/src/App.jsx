import "./styles/App.css";
import Register from "./components/Register";
import Login from "./components/Login";






import "./styles/register.css";
//import {BrowserRouter as Router,Routes,Route} from "react-router-dom";

function App() {
  return (
    <div className="App">

      <Register />
      <Login />
    </div>
  );
}

export default App;
